https://nodejs.org/en/download/releases/

https://github.com/npm/cli/releases/tag/v6.12.0
https://github.com/npm/cli/tags
https://github.com/npm/cli/releases

We got 29 Unique npm cli one's for all 148 different Node versions from Node.js 6.0.0 (2016-04-26)  and  Node.js 12.12.0 (2019-10-11) and every 148 versions in between

From <https://nodejs.org/en/download/releases/> 


curl -k -L https://github.com/npm/cli/archive/v3.10.10.zip -O
curl -k -L https://github.com/npm/cli/archive/v3.10.3.zip -O
curl -k -L https://github.com/npm/cli/archive/v3.10.8.zip -O
curl -k -L https://github.com/npm/cli/archive/v3.10.9.zip -O
curl -k -L https://github.com/npm/cli/archive/v3.8.6.zip -O
curl -k -L https://github.com/npm/cli/archive/v3.8.9.zip -O
curl -k -L https://github.com/npm/cli/archive/v3.9.3.zip -O
curl -k -L https://github.com/npm/cli/archive/v3.9.5.zip -O
curl -k -L https://github.com/npm/cli/archive/v4.0.5.zip -O
curl -k -L https://github.com/npm/cli/archive/v4.1.2.zip -O
curl -k -L https://github.com/npm/cli/archive/v4.2.0.zip -O
curl -k -L https://github.com/npm/cli/archive/v5.0.0.zip -O
curl -k -L https://github.com/npm/cli/archive/v5.0.3.zip -O
curl -k -L https://github.com/npm/cli/archive/v5.3.0.zip -O
curl -k -L https://github.com/npm/cli/archive/v5.4.2.zip -O
curl -k -L https://github.com/npm/cli/archive/v5.5.1.zip -O
curl -k -L https://github.com/npm/cli/archive/v5.6.0.zip -O
curl -k -L https://github.com/npm/cli/archive/v6.1.0.zip -O
curl -k -L https://github.com/npm/cli/archive/v6.10.0.zip -O
curl -k -L https://github.com/npm/cli/archive/v6.10.2.zip -O
curl -k -L https://github.com/npm/cli/archive/v6.10.3.zip -O
curl -k -L https://github.com/npm/cli/archive/v6.11.3.zip -O
curl -k -L https://github.com/npm/cli/archive/v6.2.0.zip -O
curl -k -L https://github.com/npm/cli/archive/v6.4.1.zip -O
curl -k -L https://github.com/npm/cli/archive/v6.5.0.zip -O
curl -k -L https://github.com/npm/cli/archive/v6.5.0-next.0.zip -O
curl -k -L https://github.com/npm/cli/archive/v6.7.0.zip -O
curl -k -L https://github.com/npm/cli/archive/v6.9.0.zip -O
curl -k -L https://github.com/npm/cli/archive/v6.12.0.zip -O
